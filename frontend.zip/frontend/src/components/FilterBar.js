// frontend/src/components/FilterBar.js
import React, { useState, useContext, useEffect } from 'react';
import { TodoContext } from '../context/TodoContext';
import '../styles/index.css';

const FilterBar = () => {
  const { 
    filters, 
    updateFilters, 
    sort, 
    updateSort,
    todos
  } = useContext(TodoContext);
  
  const [localFilters, setLocalFilters] = useState({
    tags: filters.tags || [],
    priority: filters.priority || '',
  });
  
  const [localSort, setLocalSort] = useState({
    sortBy: sort.sortBy || 'createdAt',
    sortOrder: sort.sortOrder || 'desc'
  });
  
  const [availableTags, setAvailableTags] = useState([]);
  
  // Extract unique tags from todos
  useEffect(() => {
    if (todos && todos.length > 0) {
      const tags = [];
      todos.forEach(todo => {
        if (todo.tags && todo.tags.length > 0) {
          todo.tags.forEach(tag => {
            if (!tags.includes(tag)) {
              tags.push(tag);
            }
          });
        }
      });
      setAvailableTags(tags);
    }
  }, [todos]);
  
  const handleTagToggle = (tag) => {
    setLocalFilters(prev => {
      const newTags = [...prev.tags];
      
      if (newTags.includes(tag)) {
        // Remove tag if already selected
        return {
          ...prev,
          tags: newTags.filter(t => t !== tag)
        };
      } else {
        // Add tag if not selected
        return {
          ...prev,
          tags: [...newTags, tag]
        };
      }
    });
  };
  
  const handlePriorityChange = (e) => {
    setLocalFilters(prev => ({
      ...prev,
      priority: e.target.value
    }));
  };
  
  const handleSortChange = (e) => {
    const [sortBy, sortOrder] = e.target.value.split('-');
    setLocalSort({ sortBy, sortOrder });
  };
  
  const applyFilters = () => {
    updateFilters(localFilters);
    updateSort(localSort);
  };
  
  const resetFilters = () => {
    const defaultFilters = { tags: [], priority: '' };
    const defaultSort = { sortBy: 'createdAt', sortOrder: 'desc' };
    
    setLocalFilters(defaultFilters);
    setLocalSort(defaultSort);
    updateFilters(defaultFilters);
    updateSort(defaultSort);
  };
  
  return (
    <div className="filter-bar">
      <h3>Filter & Sort</h3>
      
      <div className="filter-section">
        <div className="filter-group">
          <label>Priority</label>
          <select
            value={localFilters.priority}
            onChange={handlePriorityChange}
          >
            <option value="">All Priorities</option>
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
        </div>
        
        <div className="filter-group">
          <label>Sort By</label>
          <select
            value={`${localSort.sortBy}-${localSort.sortOrder}`}
            onChange={handleSortChange}
          >
            <option value="createdAt-desc">Newest First</option>
            <option value="createdAt-asc">Oldest First</option>
            <option value="priority-asc">Priority (Low to High)</option>
            <option value="priority-desc">Priority (High to Low)</option>
            <option value="title-asc">Title (A to Z)</option>
            <option value="title-desc">Title (Z to A)</option>
          </select>
        </div>
      </div>
      
      {availableTags.length > 0 && (
        <div className="tags-filter">
          <label>Filter by Tags</label>
          <div className="tag-buttons">
            {availableTags.map(tag => (
              <button
                key={tag}
                className={`tag-btn ${localFilters.tags.includes(tag) ? 'active' : ''}`}
                onClick={() => handleTagToggle(tag)}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
      )}
      
      <div className="filter-actions">
        <button
          className="btn btn-outline btn-sm"
          onClick={resetFilters}
        >
          Reset
        </button>
        <button
          className="btn btn-primary btn-sm"
          onClick={applyFilters}
        >
          Apply Filters
        </button>
      </div>
    </div>
  );
};

export default FilterBar;