// frontend/src/components/TodoDetails.js
import React, { useState, useEffect, useContext } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { TodoContext } from '../context/TodoContext';
import todoService from '../service/todoService';
import TodoForm from './TodoForm';
import NoteModal from './NoteModal';
import '../styles/index.css';

const TodoDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { deleteTodo } = useContext(TodoContext);
  const [todo, setTodo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showEditForm, setShowEditForm] = useState(false);
  const [showNoteModal, setShowNoteModal] = useState(false);
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);

  useEffect(() => {
    const fetchTodo = async () => {
      try {
        const data = await todoService.getTodoById(id);
        setTodo(data);
      } catch (err) {
        setError('Failed to fetch todo details');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchTodo();
  }, [id]);

  const handleDelete = async () => {
    try {
      await deleteTodo(todo._id);
      navigate('/');
    } catch (err) {
      setError('Failed to delete todo');
      console.error(err);
    }
  };

  const handleNoteAdded = (updatedTodo) => {
    setTodo(updatedTodo);
    setShowNoteModal(false);
  };

  if (loading) {
    return <div className="loading">Loading todo details...</div>;
  }

  if (error) {
    return <div className="error-message">{error}</div>;
  }

  if (!todo) {
    return <div className="not-found">Todo not found</div>;
  }

  return (
    <div className="todo-details">
      <div className="back-button">
        <button onClick={() => navigate('/')}>
          <i className="fas fa-arrow-left"></i> Back to List
        </button>
      </div>
      
      <div className="todo-details-header">
        <h1>{todo.title}</h1>
        
        <div className="todo-actions">
          <button 
            className="btn btn-outline"
            onClick={() => setShowNoteModal(true)}
          >
            <i className="fas fa-sticky-note"></i> Add Note
          </button>
          
          <button 
            className="btn btn-primary"
            onClick={() => setShowEditForm(true)}
          >
            <i className="fas fa-edit"></i> Edit
          </button>
          
          <button 
            className="btn btn-danger"
            onClick={() => setShowConfirmDelete(true)}
          >
            <i className="fas fa-trash"></i> Delete
          </button>
        </div>
      </div>
      
      <div className="todo-details-content">
        <div className="todo-info">
          <div className="info-item priority">
            <span className="label">Priority:</span>
            <span className={`value priority-${todo.priority.toLowerCase()}`}>
              {todo.priority}
            </span>
          </div>
          
          <div className="info-item">
            <span className="label">Created by:</span>
            <span className="value">
              {todo.userId.name} (@{todo.userId.username})
            </span>
          </div>
          
          <div className="info-item">
            <span className="label">Created:</span>
            <span className="value">
              {new Date(todo.createdAt).toLocaleString()}
            </span>
          </div>
          
          {todo.updatedAt !== todo.createdAt && (
            <div className="info-item">
              <span className="label">Updated:</span>
              <span className="value">
                {new Date(todo.updatedAt).toLocaleString()}
              </span>
            </div>
          )}
        </div>
        
        {todo.description && (
          <div className="description">
            <h3>Description</h3>
            <p>{todo.description}</p>
          </div>
        )}
        
        {todo.tags && todo.tags.length > 0 && (
          <div className="tags-section">
            <h3>Tags</h3>
            <div className="tags">
              {todo.tags.map((tag, index) => (
                <span key={index} className="tag">{tag}</span>
              ))}
            </div>
          </div>
        )}
        
        {todo.mentions && todo.mentions.length > 0 && (
          <div className="mentions-section">
            <h3>Mentioned Users</h3>
            <div className="mentions">
              {todo.mentions.map((user, index) => (
                <div key={index} className="mentioned-user">
                  <span className="avatar">
                    {user.avatar ? (
                      <img src={user.avatar} alt={user.name} />
                    ) : (
                      user.name.charAt(0)
                    )}
                  </span>
                  <span className="name">{user.name}</span>
                  <span className="username">@{user.username}</span>
                </div>
              ))}
            </div>
          </div>
        )}
        
        {todo.notes && todo.notes.length > 0 && (
          <div className="notes-section">
            <h3>Notes</h3>
            <div className="notes">
              {todo.notes.map((note, index) => (
                <div key={index} className="note">
                  <p>{note.content}</p>
                  <small>{new Date(note.createdAt).toLocaleString()}</small>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
      
      {showEditForm && (
        <div className="modal-overlay">
          <div className="modal">
            <TodoForm 
              todoId={todo._id}
              initialData={todo}
              onClose={() => setShowEditForm(false)}
            />
          </div>
        </div>
      )}
      
      {showNoteModal && (
        <NoteModal 
          todo={todo}
          onClose={() => setShowNoteModal(false)}
          onNoteSaved={handleNoteAdded}
        />
      )}
      
      {showConfirmDelete && (
        <div className="modal-overlay">
          <div className="modal confirm-modal">
            <h3>Confirm Delete</h3>
            <p>Are you sure you want to delete "{todo.title}"?</p>
            <div className="confirm-actions">
              <button 
                className="btn btn-outline" 
                onClick={() => setShowConfirmDelete(false)}
              >
                Cancel
              </button>
              <button 
                className="btn btn-danger" 
                onClick={handleDelete}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TodoDetails;