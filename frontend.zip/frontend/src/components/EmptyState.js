import React from 'react';
import '../styles/index.css';

const EmptyState = ({ title, message, actionText, onAction }) => {
  return (
    <div className="empty-state">
      <div className="empty-state-icon">
        <i className="fas fa-clipboard-list"></i>
      </div>
      <h2>{title || 'No Items Found'}</h2>
      <p>{message || 'There are no items to display.'}</p>
      
      {actionText && onAction && (
        <button className="btn btn-primary" onClick={onAction}>
          {actionText}
        </button>
      )}
    </div>
  );
};

export default EmptyState;