import React, { useContext, useState, useEffect } from 'react';
import { TodoContext } from '../context/TodoContext';
import userService from '../service/userService';
import '../styles/index.css';

const UserSelector = () => {
  const { currentUser, setCurrentUser } = useContext(TodoContext);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const data = await userService.getAllUsers();
        setUsers(data);
        
        // Set first user as current if none selected
        if (data.length > 0 && !currentUser) {
          setCurrentUser(data[0]);
        }
      } catch (err) {
        setError('Failed to fetch users');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchUsers();
  }, [currentUser, setCurrentUser]);

  const handleUserChange = (userId) => {
    const selectedUser = users.find(user => user._id === userId);
    setCurrentUser(selectedUser);
  };

  if (loading) {
    return <div className="loading">Loading users...</div>;
  }

  if (error) {
    return <div className="error-message">{error}</div>;
  }

  return (
    <div className="user-selector">
      <label htmlFor="user-select">Select User:</label>
      <select
        id="user-select"
        value={currentUser?._id || ''}
        onChange={(e) => handleUserChange(e.target.value)}
      >
        {users.map(user => (
          <option key={user._id} value={user._id}>
            {user.name} (@{user.username})
          </option>
        ))}
      </select>
    </div>
  );
};

export default UserSelector;