// frontend/src/components/TodoForm.js
import React, { useState, useContext, useEffect } from 'react';
import { TodoContext } from '../context/TodoContext';
import '../styles/index.css';

const TodoForm = ({ todoId, initialData, onClose }) => {
  const { createTodo, updateTodo, users } = useContext(TodoContext);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    priority: 'Medium',
    tags: '',
    mentions: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    // If editing an existing todo, populate the form
    if (initialData) {
      setFormData({
        title: initialData.title || '',
        description: initialData.description || '',
        priority: initialData.priority || 'Medium',
        tags: initialData.tags ? initialData.tags.join(', ') : '',
        mentions: initialData.mentions ? initialData.mentions.map(user => user.username).join(', ') : ''
      });
    }
  }, [initialData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      // Process form data
      const todoData = {
        title: formData.title,
        description: formData.description,
        priority: formData.priority,
        tags: formData.tags ? formData.tags.split(',').map(tag => tag.trim()) : [],
        mentions: formData.mentions ? formData.mentions.split(',').map(mention => mention.trim()) : []
      };

      if (todoId) {
        // Update existing todo
        await updateTodo(todoId, todoData);
      } else {
        // Create new todo
        await createTodo(todoData);
      }

      onClose();
    } catch (err) {
      setError('Failed to save todo. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="todo-form">
      <div className="form-header">
        <h2>{todoId ? 'Edit Todo' : 'Create New Todo'}</h2>
        <button className="close-btn" onClick={onClose}>×</button>
      </div>

      {error && <div className="error-message">{error}</div>}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="title">Title *</label>
          <input
            type="text"
            id="title"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="description">Description</label>
          <textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            rows="4"
          ></textarea>
        </div>

        <div className="form-group">
          <label htmlFor="priority">Priority</label>
          <select
            id="priority"
            name="priority"
            value={formData.priority}
            onChange={handleChange}
          >
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
        </div>

        <div className="form-group">
          <label htmlFor="tags">Tags (comma separated)</label>
          <input
            type="text"
            id="tags"
            name="tags"
            value={formData.tags}
            onChange={handleChange}
            placeholder="work, personal, urgent"
          />
        </div>

        <div className="form-group">
          <label htmlFor="mentions">Mention Users (comma separated)</label>
          <input
            type="text"
            id="mentions"
            name="mentions"
            value={formData.mentions}
            onChange={handleChange}
            placeholder="johndoe, janedoe"
          />
          <small>Available users: {users.map(user => user.username).join(', ')}</small>
        </div>

        <div className="form-actions">
          <button 
            type="button" 
            className="btn btn-outline" 
            onClick={onClose}
            disabled={loading}
          >
            Cancel
          </button>
          <button 
            type="submit" 
            className="btn btn-primary"
            disabled={loading}
          >
            {loading ? 'Saving...' : todoId ? 'Update Todo' : 'Create Todo'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default TodoForm;