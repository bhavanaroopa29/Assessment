// frontend/src/components/NoteModal.js
import React, { useState, useContext } from 'react';
import { TodoContext } from '../context/TodoContext';
import '../styles/index.css';

const NoteModal = ({ todo, onClose, onNoteSaved }) => {
  const { addNote } = useContext(TodoContext);
  const [noteContent, setNoteContent] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!noteContent.trim()) {
      setError('Note content cannot be empty');
      return;
    }
    
    setLoading(true);
    setError('');
    
    try {
      const updatedTodo = await addNote(todo._id, noteContent);
      
      if (onNoteSaved) {
        onNoteSaved(updatedTodo);
      } else {
        onClose();
      }
    } catch (err) {
      setError('Failed to add note. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal note-modal">
        <div className="modal-header">
          <h3>Add Note to "{todo.title}"</h3>
          <button className="close-btn" onClick={onClose}>×</button>
        </div>
        
        {error && <div className="error-message">{error}</div>}
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="noteContent">Note Content</label>
            <textarea
              id="noteContent"
              value={noteContent}
              onChange={(e) => setNoteContent(e.target.value)}
              placeholder="Write your note here..."
              rows="4"
              required
            ></textarea>
          </div>
          
          <div className="form-actions">
            <button 
              type="button" 
              className="btn btn-outline" 
              onClick={onClose}
              disabled={loading}
            >
              Cancel
            </button>
            <button 
              type="submit" 
              className="btn btn-primary"
              disabled={loading}
            >
              {loading ? 'Adding...' : 'Add Note'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NoteModal;