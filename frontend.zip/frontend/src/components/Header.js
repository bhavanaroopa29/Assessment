// frontend/src/components/Header.js
import React, { useContext, useState } from 'react';
import { Link } from 'react-router-dom';
import { TodoContext } from '../context/TodoContext';
import TodoForm from './TodoForm';
import '../styles/index.css';

const Header = () => {
  const { exportTodos, currentUser } = useContext(TodoContext);
  const [showForm, setShowForm] = useState(false);

  const handleExport = (format) => {
    exportTodos(format);
  };

  return (
    <header className="header">
      <div className="header-content">
        <Link to="/" className="logo">
          Todo List App
        </Link>
        
        <div className="header-actions">
          {currentUser && (
            <>
              <button className="btn btn-primary" onClick={() => setShowForm(true)}>
                <i className="fas fa-plus"></i> New Todo
              </button>
              
              <div className="dropdown">
                <button className="btn btn-outline">
                  <i className="fas fa-download"></i> Export
                </button>
                <div className="dropdown-content">
                  <button onClick={() => handleExport('json')}>Export as JSON</button>
                  <button onClick={() => handleExport('csv')}>Export as CSV</button>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
      
      {showForm && (
        <div className="modal-overlay">
          <div className="modal">
            <TodoForm onClose={() => setShowForm(false)} />
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;