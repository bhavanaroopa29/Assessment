// frontend/src/components/TodoItem.js
import React, { useState, useContext } from 'react';
import { Link } from 'react-router-dom';
import { TodoContext } from '../context/TodoContext';
import TodoForm from './TodoForm';
import '../styles/index.css';

const TodoItem = ({ todo, onAddNote }) => {
  const { deleteTodo } = useContext(TodoContext);
  const [showEditForm, setShowEditForm] = useState(false);
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);

  const getPriorityClass = (priority) => {
    switch (priority) {
      case 'High':
        return 'priority-high';
      case 'Medium':
        return 'priority-medium';
      case 'Low':
        return 'priority-low';
      default:
        return '';
    }
  };

  const handleDelete = async () => {
    try {
      await deleteTodo(todo._id);
      setShowConfirmDelete(false);
    } catch (err) {
      console.error('Error deleting todo:', err);
    }
  };

  return (
    <div className={`todo-item ${getPriorityClass(todo.priority)}`}>
      <div className="todo-content">
        <Link to={`/todo/${todo._id}`} className="todo-title">
          {todo.title}
        </Link>
        
        <div className="todo-meta">
          <span className="todo-priority">
            {todo.priority}
          </span>
          
          {todo.tags && todo.tags.length > 0 && (
            <div className="todo-tags">
              {todo.tags.map((tag, index) => (
                <span key={index} className="tag">{tag}</span>
              ))}
            </div>
          )}
          
          {todo.mentions && todo.mentions.length > 0 && (
            <div className="todo-mentions">
              {todo.mentions.map((user, index) => (
                <span key={index} className="mention">@{user.username}</span>
              ))}
            </div>
          )}
        </div>
        
        {todo.description && (
          <p className="todo-description">{todo.description}</p>
        )}
      </div>
      
      <div className="todo-actions">
        <button 
          className="icon-btn note-btn" 
          title="Add Note"
          onClick={onAddNote}
        >
          <i className="fas fa-sticky-note"></i>
        </button>
        
        <button 
          className="icon-btn edit-btn" 
          title="Edit Todo"
          onClick={() => setShowEditForm(true)}
        >
          <i className="fas fa-edit"></i>
        </button>
        
        <button 
          className="icon-btn delete-btn" 
          title="Delete Todo"
          onClick={() => setShowConfirmDelete(true)}
        >
          <i className="fas fa-trash"></i>
        </button>
      </div>
      
      {showEditForm && (
        <div className="modal-overlay">
          <div className="modal">
            <TodoForm 
              todoId={todo._id}
              initialData={todo}
              onClose={() => setShowEditForm(false)}
            />
          </div>
        </div>
      )}
      
      {showConfirmDelete && (
        <div className="modal-overlay">
          <div className="modal confirm-modal">
            <h3>Confirm Delete</h3>
            <p>Are you sure you want to delete "{todo.title}"?</p>
            <div className="confirm-actions">
              <button 
                className="btn btn-outline" 
                onClick={() => setShowConfirmDelete(false)}
              >
                Cancel
              </button>
              <button 
                className="btn btn-danger" 
                onClick={handleDelete}
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TodoItem;