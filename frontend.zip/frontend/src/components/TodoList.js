// frontend/src/components/TodoList.js
import React, { useContext, useState } from 'react';
import { TodoContext } from '../context/TodoContext';
import TodoItem from './TodoItem';
import FilterBar from './FilterBar';
import Pagination from './Pagination';
import NoteModal from './NoteModal';
import '../styles/index.css';

const TodoList = () => {
  const { 
    todos, 
    loading, 
    error, 
    currentUser,
    pagination,
    changePage
  } = useContext(TodoContext);
  
  const [selectedTodo, setSelectedTodo] = useState(null);
  const [showNoteModal, setShowNoteModal] = useState(false);

  const handleAddNote = (todo) => {
    setSelectedTodo(todo);
    setShowNoteModal(true);
  };

  if (!currentUser) {
    return (
      <div className="todo-list-container">
        <div className="empty-state">
          <h2>No User Selected</h2>
          <p>Please select a user to view their todo list.</p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="todo-list-container">
        <div className="loading">Loading todos...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="todo-list-container">
        <div className="error-message">{error}</div>
      </div>
    );
  }

  return (
    <div className="todo-list-container">
      <FilterBar />
      
      <div className="todo-list">
        <h2>
          {currentUser.name}'s Todo List
          <span className="todo-count">({todos.length} items)</span>
        </h2>
        
        {todos.length === 0 ? (
          <div className="empty-state">
            <p>No todos found. Create a new todo to get started!</p>
          </div>
        ) : (
          <>
            <div className="todo-items">
              {todos.map(todo => (
                <TodoItem 
                  key={todo._id} 
                  todo={todo} 
                  onAddNote={() => handleAddNote(todo)}
                />
              ))}
            </div>
            
            <Pagination 
              currentPage={pagination.currentPage}
              totalPages={pagination.totalPages}
              onPageChange={changePage}
            />
          </>
        )}
      </div>
      
      {showNoteModal && selectedTodo && (
        <NoteModal 
          todo={selectedTodo}
          onClose={() => setShowNoteModal(false)}
        />
      )}
    </div>
  );
};

export default TodoList;