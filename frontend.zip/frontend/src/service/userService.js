// frontend/src/services/userService.js
const API_URL = 'http://localhost:5000/api';

// Get all users
const getAllUsers = async () => {
  const response = await fetch(`${API_URL}/users`);
  
  if (!response.ok) {
    throw new Error('Failed to fetch users');
  }
  
  return response.json();
};

// Get a specific user by ID
const getUserById = async (id) => {
  const response = await fetch(`${API_URL}/users/${id}`);
  
  if (!response.ok) {
    throw new Error('Failed to fetch user');
  }
  
  return response.json();
};

// Get todos for a specific user
const getUserTodos = async (id, params = {}) => {
  const queryParams = new URLSearchParams(params).toString();
  const response = await fetch(`${API_URL}/users/${id}/todos?${queryParams}`);
  
  if (!response.ok) {
    throw new Error('Failed to fetch user todos');
  }
  
  return response.json();
};

const userService = {
  getAllUsers,
  getUserById,
  getUserTodos
};

export default userService;