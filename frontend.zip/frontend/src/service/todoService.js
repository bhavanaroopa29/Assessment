// frontend/src/services/todoService.js (continued)
const API_URL = 'http://localhost:5000/api';

// Convert query params object to URL query string
const buildQueryString = (params) => {
  return Object.keys(params)
    .filter(key => params[key] !== undefined && params[key] !== '')
    .map(key => `${encodeURIComponent(key)}=${encodeURIComponent(params[key])}`)
    .join('&');
};

// Get all todos with optional filters
const getTodos = async (params = {}) => {
  const queryString = buildQueryString(params);
  const response = await fetch(`${API_URL}/todos?${queryString}`);
  
  if (!response.ok) {
    throw new Error('Failed to fetch todos');
  }
  
  return response.json();
};

// Get a specific todo by ID
const getTodoById = async (id) => {
  const response = await fetch(`${API_URL}/todos/${id}`);
  
  if (!response.ok) {
    throw new Error('Failed to fetch todo');
  }
  
  return response.json();
};

// Create a new todo
const createTodo = async (todoData) => {
  const response = await fetch(`${API_URL}/todos`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(todoData)
  });
  
  if (!response.ok) {
    throw new Error('Failed to create todo');
  }
  
  return response.json();
};

// Update a todo
const updateTodo = async (id, todoData) => {
  const response = await fetch(`${API_URL}/todos/${id}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(todoData)
  });
  
  if (!response.ok) {
    throw new Error('Failed to update todo');
  }
  
  return response.json();
};

// Delete a todo
const deleteTodo = async (id) => {
  const response = await fetch(`${API_URL}/todos/${id}`, {
    method: 'DELETE'
  });
  
  if (!response.ok) {
    throw new Error('Failed to delete todo');
  }
  
  return response.json();
};

// Add a note to a todo
const addNote = async (id, noteData) => {
  const response = await fetch(`${API_URL}/todos/${id}/notes`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(noteData)
  });
  
  if (!response.ok) {
    throw new Error('Failed to add note');
  }
  
  return response.json();
};

// Export todos
const exportTodos = async (format, userId) => {
  // Using window.open to trigger file download
  window.open(`${API_URL}/todos/export/${format}?userId=${userId}`, '_blank');
  return true;
};

const todoService = {
  getTodos,
  getTodoById,
  createTodo,
  updateTodo,
  deleteTodo,
  addNote,
  exportTodos
};

export default todoService;