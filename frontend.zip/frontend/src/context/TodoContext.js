import React, { createContext, useState, useEffect } from 'react';
import todoService from '../service/todoService';
import userService from '../service/userService';

export const TodoContext = createContext();

export const TodoProvider = ({ children }) => {
  const [todos, setTodos] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [currentUser, setCurrentUser] = useState(null);
  const [users, setUsers] = useState([]);
  
  // Pagination
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
    limit: 10
  });
  
  // Filters and sorting
  const [filters, setFilters] = useState({
    tags: [],
    priority: ''
  });
  
  const [sort, setSort] = useState({
    sortBy: 'createdAt',
    sortOrder: 'desc'
  });
  
  // Fetch users on component mount
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const data = await userService.getAllUsers();
        setUsers(data);
        
        // Set first user as current if none selected
        if (data.length > 0 && !currentUser) {
          setCurrentUser(data[0]);
        }
      } catch (err) {
        console.error('Failed to fetch users:', err);
      }
    };
    
    fetchUsers();
  }, []);
  
  // Fetch todos when currentUser changes or filters/sort/pagination changes
  useEffect(() => {
    if (!currentUser) return;
    
    const fetchTodos = async () => {
      setLoading(true);
      setError('');
      
      try {
        const params = {
          page: pagination.currentPage,
          limit: pagination.limit,
          sortBy: sort.sortBy,
          sortOrder: sort.sortOrder,
          tags: filters.tags.join(','),
          priority: filters.priority
        };
        
        const data = await userService.getUserTodos(currentUser._id, params);
        
        setTodos(data.todos);
        setPagination({
          ...pagination,
          totalPages: data.totalPages
        });
      } catch (err) {
        setError('Failed to fetch todos');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchTodos();
  }, [currentUser, filters, sort, pagination.currentPage, pagination.limit]);
  
  // Update filters
  const updateFilters = (newFilters) => {
    setFilters(newFilters);
    // Reset to first page when filters change
    setPagination({
      ...pagination,
      currentPage: 1
    });
  };
  
  // Update sort
  const updateSort = (newSort) => {
    setSort(newSort);
  };
  
  // Change page
  const changePage = (page) => {
    setPagination({
      ...pagination,
      currentPage: page
    });
  };
  
  // Create a new todo
  const createTodo = async (todoData) => {
    try {
      // Add the userId to the todo data
      const newTodoData = {
        ...todoData,
        userId: currentUser._id
      };
      
      const newTodo = await todoService.createTodo(newTodoData);
      
      // Update the todos list with the new todo
      setTodos(prevTodos => [newTodo, ...prevTodos]);
      
      return newTodo;
    } catch (err) {
      console.error('Error creating todo:', err);
      throw err;
    }
  };
  
  // Update a todo
  const updateTodo = async (id, todoData) => {
    try {
      const updatedTodo = await todoService.updateTodo(id, todoData);
      
      // Update the todos list with the updated todo
      setTodos(prevTodos => 
        prevTodos.map(todo => 
          todo._id === id ? updatedTodo : todo
        )
      );
      
      return updatedTodo;
    } catch (err) {
      console.error('Error updating todo:', err);
      throw err;
    }
  };
  
  // Delete a todo
  const deleteTodo = async (id) => {
    try {
      await todoService.deleteTodo(id);
      
      // Remove the deleted todo from the list
      setTodos(prevTodos => 
        prevTodos.filter(todo => todo._id !== id)
      );
      
      return true;
    } catch (err) {
      console.error('Error deleting todo:', err);
      throw err;
    }
  };
  
  // Add a note to a todo
  const addNote = async (id, noteContent) => {
    try {
      const noteData = { content: noteContent };
      const updatedTodo = await todoService.addNote(id, noteData);
      
      // Update the todos list with the updated todo
      setTodos(prevTodos => 
        prevTodos.map(todo => 
          todo._id === id ? updatedTodo : todo
        )
      );
      
      return updatedTodo;
    } catch (err) {
      console.error('Error adding note:', err);
      throw err;
    }
  };
  
  // Export todos
  const exportTodos = async (format) => {
    try {
      await todoService.exportTodos(format, currentUser._id);
      return true;
    } catch (err) {
      console.error('Error exporting todos:', err);
      throw err;
    }
  };
  
  const contextValue = {
    todos,
    loading,
    error,
    currentUser,
    setCurrentUser,
    users,
    pagination,
    filters,
    sort,
    updateFilters,
    updateSort,
    changePage,
    createTodo,
    updateTodo,
    deleteTodo,
    addNote,
    exportTodos
  };
  
  return (
    <TodoContext.Provider value={contextValue}>
      {children}
    </TodoContext.Provider>
  );
};