import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { TodoProvider } from './context/TodoContext';
import Header from './components/Header';
import UserSelector from './components/UserSelector';
import TodoList from './components/TodoList';
import TodoDetails from './components/TodoDetails';
import Footer from './components/Footer';
import './styles/App.css';

const App = () => {
  return (
    <TodoProvider>
      <Router>
        <div className="app">
          <Header />
          
          <main className="main-content">
            <div className="container">
              <UserSelector />
              
              <Routes>
                <Route path="/" element={<TodoList />} />
                <Route path="/todo/:id" element={<TodoDetails />} />
              </Routes>
            </div>
          </main>
          
          <Footer />
        </div>
      </Router>
    </TodoProvider>
  );
};

export default App;