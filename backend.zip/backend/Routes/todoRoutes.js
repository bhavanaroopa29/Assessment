// backend/Routes/todoRoutes.js
const express = require('express');
const router = express.Router();
const todoController = require('../Controller/todoController');

// Make sure todoController is properly imported and functions exist
console.log("Available functions in todoController:", Object.keys(todoController));

// Export route should be BEFORE any routes with parameters 
router.get('/export/:format', todoController.exportTodos);

// Get all todos with filtering, sorting, and pagination
router.get('/', todoController.getTodos);

// Get a single todo
router.get('/:id', todoController.getTodoById);

// Create a new todo
router.post('/', todoController.createTodo);

// Update a todo
router.put('/:id', todoController.updateTodo);

// Delete a todo
router.delete('/:id', todoController.deleteTodo);

// Add a note to a todo
router.post('/:id/notes', todoController.addNote);

module.exports = router;