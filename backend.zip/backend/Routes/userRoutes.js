const express = require('express');
const router = express.Router();
const userController = require('../Controller/userController'); // Corrected path

// Get all users
router.get('/', userController.getAllUsers);

// Get a single user
router.get('/:id', userController.getUserById);

// Get todos for a specific user
router.get('/:id/todos', userController.getUserTodos);

module.exports = router;
