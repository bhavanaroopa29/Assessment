const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const todoRoutes = require('./Routes/todoRoutes');
const userRoutes = require('./Routes/userRoutes');
const morgan = require('morgan');

// Load environment variables
dotenv.config();

// Initialize express app
const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));  // HTTP request logger for development

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/todo-app')
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Could not connect to MongoDB', err));

// Routes
app.use('/api/todos', todoRoutes);
app.use('/api/users', userRoutes);

// Seed users if needed (only in development or if users are empty)
const seedUsers = require('./seed');
const User = require('./models/User');

// Use async/await instead of callbacks
async function checkAndSeedUsers() {
  try {
    const count = await User.countDocuments();
    if (count === 0) {
      await seedUsers();
    }
  } catch (err) {
    console.error('Error checking user count', err);
  }
}

// Call the async function
checkAndSeedUsers();

// Global error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong' });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});