// backend/utils/exportData.js
// Simple version without dependencies
exports.exportToJson = (res, data) => {
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', 'attachment; filename=todos.json');
  res.json(data);
};

exports.exportToCsv = (res, data) => {
  // Convert data to CSV format
  const headers = ['ID', 'Title', 'Description', 'Priority', 'Status', 'Tags', 'User', 'Mentions', 'Created', 'Updated'];
  
  // Create CSV content
  let csvContent = headers.join(',') + '\r\n';
  
  data.forEach(todo => {
    const row = [
      todo._id.toString(),
      `"${todo.title.replace(/"/g, '""')}"`,
      `"${(todo.description || '').replace(/"/g, '""')}"`,
      todo.priority || 'medium',
      todo.status || 'pending',
      `"${(todo.tags || []).join(',')}"`,
      todo.userId ? todo.userId.username : '',
      `"${(todo.mentions || []).map(u => u.username).join(',')}"`,
      todo.createdAt ? new Date(todo.createdAt).toISOString() : '',
      todo.updatedAt ? new Date(todo.updatedAt).toISOString() : ''
    ];
    
    csvContent += row.join(',') + '\r\n';
  });
  
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename=todos.csv');
  res.send(csvContent);
};